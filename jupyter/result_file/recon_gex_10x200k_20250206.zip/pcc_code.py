import scipy.stats as ss
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.pyplot import rc_context
import seaborn as sns

recon_rna_joint_long = pd.read_csv('./data/recon_gex_10x200k_20250206.csv',index_col=0)
gene = 'GZMB' #or CCR7, GZMK, NKG7
correlation1 = ss.pearsonr(recon_rna_joint_long.loc[recon_rna_joint_long.Gene.isin([gene]),'MIST with TCR'].tolist(),  
                          recon_rna_joint_long.loc[recon_rna_joint_long.Gene.isin([gene]),'RAW'].tolist())[0]
print(correlation1)
correlation2 = ss.pearsonr(recon_rna_joint_long.loc[recon_rna_joint_long.Gene.isin([gene]),'MIST without TCR'].tolist(),  
                            recon_rna_joint_long.loc[recon_rna_joint_long.Gene.isin([gene]),'RAW'].tolist())[0]
print(correlation2)
correlation3 = ss.pearsonr(recon_rna_joint_long.loc[recon_rna_joint_long.Gene.isin([gene]),'MAGIC'].tolist(),  
                          recon_rna_joint_long.loc[recon_rna_joint_long.Gene.isin([gene]),'RAW'].tolist())[0]
print(correlation3)
correlation4 = ss.pearsonr(recon_rna_joint_long.loc[recon_rna_joint_long.Gene.isin([gene]),'MAGIC'].tolist(),  
                            recon_rna_joint_long.loc[recon_rna_joint_long.Gene.isin([gene]),'MIST with TCR'].tolist())[0]
print(correlation4)

correlation5 = ss.pearsonr(recon_rna_joint_long.loc[recon_rna_joint_long.Gene.isin([gene]),'MAGIC'].tolist(),  
                            recon_rna_joint_long.loc[recon_rna_joint_long.Gene.isin([gene]),'MIST without TCR'].tolist())[0]
print(correlation5)

correlation6 = ss.pearsonr(recon_rna_joint_long.loc[recon_rna_joint_long.Gene.isin([gene]),'DCA'].tolist(),  
                          recon_rna_joint_long.loc[recon_rna_joint_long.Gene.isin([gene]),'RAW'].tolist())[0]
print(correlation6)
correlation7 = ss.pearsonr(recon_rna_joint_long.loc[recon_rna_joint_long.Gene.isin([gene]),'DCA'].tolist(),  
                            recon_rna_joint_long.loc[recon_rna_joint_long.Gene.isin([gene]),'MIST with TCR'].tolist())[0]
print(correlation7)

correlation8 = ss.pearsonr(recon_rna_joint_long.loc[recon_rna_joint_long.Gene.isin([gene]),'DCA'].tolist(),  
                            recon_rna_joint_long.loc[recon_rna_joint_long.Gene.isin([gene]),'MIST without TCR'].tolist())[0]
print(correlation8)